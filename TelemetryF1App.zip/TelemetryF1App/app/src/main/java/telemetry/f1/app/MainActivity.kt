package telemetry.f1.app

// This file is intentionally left blank to resolve a build issue.
