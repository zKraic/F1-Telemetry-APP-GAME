package telemetry.f1.app.ui.theme

// This file is intentionally left blank to resolve a build issue.
